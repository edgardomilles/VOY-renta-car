import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import VOYRentACarDesign from './App'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <VOYRentACarDesign />
  </React.StrictMode>,
)
