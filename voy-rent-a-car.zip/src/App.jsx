import React from "react";
import { motion } from "framer-motion";
import { Car, CalendarClock, MapPin, ShieldCheck, Zap, Gauge, Phone } from "lucide-react";

/* ... (resto del código completo del usuario) ... */
